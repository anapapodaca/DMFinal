package com.example.kpsafe;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Calendar;
import java.util.Locale;

public class Cambiar extends AppCompatActivity {

    EditText rtoCar, tmprtr, idBracalete;
    String rtmocard, tempcorp, idBrc;

    public static final String DATABASE_NAME = "kpsafe";
    public static final String url = "jdbc:mysql://kpsafe.cd4qsfjwnlel.us-east-1.rds.amazonaws.com:3306/" +
            DATABASE_NAME;
    public static final String username = "admin", password = "kpsafe2022";
    public static final String TABLE_NAME = "registros";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cambiar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        rtoCar = findViewById(R.id.ingrRitmocar);
        tmprtr = findViewById(R.id.ingrTempertr);
        idBracalete= findViewById(R.id.ingrBracalete);
    }

    public void actlzr(View view) throws SQLException {
        new Thread(() -> {
            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection connection = DriverManager.getConnection(url, username, password);
                Statement statement = connection.createStatement();
                Statement statement2 = connection.createStatement();

                idBrc= idBracalete.getText().toString();
                rtmocard = rtoCar.getText().toString();
                tempcorp = tmprtr.getText().toString();

                statement.execute("UPDATE " + TABLE_NAME + " SET rpmSalud = '" + rtmocard + "' where idbracalete = " +idBrc );
                statement2.execute("UPDATE " + TABLE_NAME + " SET tempSalud = '" + tempcorp + "' where idbracalete = " +idBrc);
                connection.close();
                finish();
                startActivity(new Intent(Cambiar.this, Salud.class));

            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }
}
