package com.example.kpsafe;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Salud extends AppCompatActivity {

    TextView rtocdc, tmpcorpl;
    Button actualizar;

    public static final String DATABASE_NAME = "kpsafe";
    public static final String url = "jdbc:mysql://kpsafe.cd4qsfjwnlel.us-east-1.rds.amazonaws.com:3306/" +
            DATABASE_NAME;
    public static final String username = "admin", password = "kpsafe2022";
    public static final String TABLE_NAME = "registros";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_salud);
        rtocdc= findViewById(R.id.ingRitmo);
        tmpcorpl= findViewById(R.id.ingTemp);
        actualizar= findViewById(R.id.btnActualizar);
        actualizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(Salud.this, Cambiar.class);
                startActivity(intent);
            }
        });

        try {
            mostrarDatos();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void mostrarDatos() throws SQLException {
        new Thread(() -> {
            StringBuilder records = new StringBuilder();
            StringBuilder records2 = new StringBuilder();
            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection connection = DriverManager.getConnection(url, username, password);
                Statement statement = connection.createStatement();

                ResultSet rs = statement.executeQuery("SELECT * FROM " + TABLE_NAME);
                while (rs.next()) {
                    records.append("Ritmo: ").append(rs.getString(3));
                    records2.append("Temperatura: ").append(rs.getString(4));
                }
                connection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    rtocdc.setText(records.toString());
                    tmpcorpl.setText(records2.toString());
                }
            });
        }).start();
    }
}
