package com.example.kpsafe;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {

    EditText correoe, contraseña;
    Button ingresar, registrarse, recp;
    FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        correoe= findViewById(R.id.ingId);
        contraseña= findViewById(R.id.ingContraseña);

        ingresar= findViewById(R.id.btnIngersar);
        registrarse= findViewById(R.id.btnRegistrar);
        recp= findViewById(R.id.btnRecp);

        auth= FirebaseAuth.getInstance();


        ingresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String mail= correoe.getText().toString().trim();
                String contra= contraseña.getText().toString().trim();

                auth.signInWithEmailAndPassword(mail,contra).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()){
                            Intent intent= new Intent(MainActivity.this,Perfil.class);
                            startActivity(intent);
                        } else {
                            Toast.makeText(MainActivity.this,"Error",Toast.LENGTH_SHORT).show();
                        }
                    }
                });

            }
        });

        registrarse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(MainActivity.this,Registro.class);
                startActivity(intent);
            }
        });

        recp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(MainActivity.this,Recuperar.class);
                startActivity(intent);
            }
        });

    }
}