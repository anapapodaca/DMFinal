package com.example.kpsafe;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class Registro extends AppCompatActivity {

    EditText correoe, contraseña, id;
    Button registrarse;
    FirebaseAuth auth;

    public static final String DATABASE_NAME = "kpsafe";
    public static final String url = "jdbc:mysql://kpsafe.cd4qsfjwnlel.us-east-1.rds.amazonaws.com:3306/" +
            DATABASE_NAME;
    public static final String username = "admin", password = "kpsafe2022";
    public static final String TABLE_NAME = "registros";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true); //regresar

        correoe= findViewById(R.id.ingCorreo);
        contraseña= findViewById(R.id.ingContraseña);
        id= findViewById(R.id.ingIdBracalete);
        auth= FirebaseAuth.getInstance();


        registrarse= findViewById(R.id.btnRegistrarse);
        //
        registrarse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String corr= correoe.getText().toString().trim();
                String idbclte= id.getText().toString().trim();
                String contra= contraseña.getText().toString().trim();
                String pulso= "0";
                String tptr= "0";
                insertData(idbclte,corr,pulso,tptr);
                auth.createUserWithEmailAndPassword(corr,contra).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()){
                            Toast.makeText(Registro.this,"Se registro correctamente",Toast.LENGTH_SHORT).show();
                            Intent intent= new Intent(Registro.this,MainActivity.class);
                            startActivity(intent);
                        } else {
                            Toast.makeText(Registro.this,"Error",Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });
    }

    public void insertData(String id, String email, String pls, String tmprta) {
        new Thread(() -> {
            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection connection = DriverManager.getConnection(url, username, password);
                Statement statement = connection.createStatement();
                statement.execute("INSERT INTO " + TABLE_NAME + "(idbracalete,mailSalud, rpmSalud,tempSalud) VALUES('" + id + "', '" + email + "', '" + pls + "','" + tmprta + "')");
                connection.close();
                finish();

            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }
}