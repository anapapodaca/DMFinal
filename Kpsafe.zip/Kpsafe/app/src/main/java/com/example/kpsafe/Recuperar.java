package com.example.kpsafe;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;

public class Recuperar extends AppCompatActivity {

    EditText correoe;
    Button rec;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recuperar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        correoe= findViewById(R.id.ingCorr);
        rec= findViewById(R.id.btnRest);

        rec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String mail= correoe.getText().toString().trim();
                validarcorreo(mail);
            }
        });
    }

    public void validarcorreo(String email){
        FirebaseAuth auth= FirebaseAuth.getInstance();
        auth.sendPasswordResetEmail(email).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()){
                            Toast.makeText(Recuperar.this,"Revise su correo",Toast.LENGTH_SHORT).show();
                            Intent intent= new Intent(Recuperar.this,MainActivity.class);
                            startActivity(intent);
                            finish();
                        } else{
                            Toast.makeText(Recuperar.this,"No existe ese usuario.",Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }
}